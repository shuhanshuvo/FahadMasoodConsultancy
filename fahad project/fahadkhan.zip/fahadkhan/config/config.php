<?php
define("DB_HOST", "localhost");
define("DB_USER", "impijush_fileup");
define("DB_PASS", "@@fileup@@45");
define("DB_NAME", "impijush_fileupwithlogin");
define("TITLE", "Welcome to my site");
define("AUTHOR", "Pijush");
